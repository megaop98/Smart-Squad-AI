COLORS = {
    'bg': '#0b0c10', 
    'panel': '#1f2833', 
    'pitch': '#133520', 
    'accent': '#66fcf1', 
    'accent2': '#ff007f', 
    'text': '#ffffff', 
    'border': '#45a29e',
    'faded': '#2c3e50'
}

STATS_KEYS = ['Pace', 'Shooting', 'Passing', 'Dribbling', 'Defending', 'Physic', 'Goalkeeping']

QUOTES = [
    ('"I will forgive if the players cannot get it right,\nbut not if they do not try hard."', "- Pep Guardiola"),
    ('"The ball is the only thing that doesn\'t sweat.\nLet it do the running."', "- Luis Enrique"),
    ('"Success is not an accident.\nIt\'s hard work, perseverance, and learning."', "- Hansi Flick"),
    ('"If you have the ball,\nyou must make the pitch as big as possible."', "- Johan Cruyff"),
    ('"Football is a simple game. Twenty-two men chase a ball for 90 minutes and at the end, the Germans always win."', "- Gary Lineker"),
    ('"I am not a perfectionist,\nbut I like to feel that things are done well."', "- Carlo Ancelotti"),
    ('"The most important thing is to win.\nThe second most important thing is to win."', "- Jose Mourinho"),
    ('"You have to win and play well. If you win and play badly, it\'s an empty feeling."', "- Marcelo Bielsa"),
    ('"To win you have to score one more goal than your opponent."', "- Diego Simeone"),
    ('"In football, the worst blindness is only seeing the ball."', "- Nelson Acosta")
]

FORMATION_INFO = {
    "4-3-3": "STRENGTH: Excellent attacking width and high pressing capability.\n\nWEAKNESS: Midfield can be overrun if the wingers don't track back defensively.",
    "4-4-2": "STRENGTH: Solid defensive structure and great wide play with overlapping fullbacks.\n\nWEAKNESS: Can lack creativity centrally and struggle against 3-man midfields.",
    "3-5-2": "STRENGTH: Dominates possession in the center and provides a dual striker threat.\n\nWEAKNESS: Vulnerable on the flanks if wing-backs are caught too high up the pitch.",
    "5-4-1": "STRENGTH: Extremely defensively resilient, compact, and hard to break down.\n\nWEAKNESS: Strikers can become very isolated, making counter-attacks difficult.",
    "4-2-3-1": "STRENGTH: Great balance of defense and attack, utilizes a true central playmaker.\n\nWEAKNESS: Requires elite holding midfielders; the lone striker can be isolated."
}