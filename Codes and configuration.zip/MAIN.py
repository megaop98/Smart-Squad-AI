import warnings
warnings.filterwarnings("ignore")

import tkinter as tk
from tkinter import filedialog, ttk
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
import threading
from math import pi

from Config import COLORS, STATS_KEYS, QUOTES, FORMATION_INFO
from ML_engine import SquadArchitectEngine

class ModernButton(tk.Frame):
    def __init__(self, parent, text, command, **kwargs):
        super().__init__(parent, bg=COLORS['accent'], cursor='hand2', padx=2, pady=2, **kwargs)
        self.command = command
        self.lbl = tk.Label(self, text=text, bg='black', fg=COLORS['accent'], font=('Impact', 22), padx=40, pady=15)
        self.lbl.pack(expand=True, fill='both')
        self.lbl.bind('<Enter>', lambda e: self.lbl.config(bg=COLORS['panel'], fg=COLORS['accent2']))
        self.lbl.bind('<Leave>', lambda e: self.lbl.config(bg='black', fg=COLORS['accent']))
        self.lbl.bind('<Button-1>', lambda e: self.command())

class TacticalApp:
    def __init__(self, root):
        self.root = root
        self.root.title("SMART SQUAD AI - TACTICAL ANALYSIS & TEAM MANAGEMENT")
        self.root.geometry("1400x900")
        self.root.configure(bg=COLORS['bg'])
        
        self.style = ttk.Style()
        self.style.theme_use('clam')
        
        self.style.configure('Horizontal.TProgressbar', background=COLORS['accent'], troughcolor=COLORS['bg'], bordercolor=COLORS['panel'], thickness=15)
        
        self.style.configure('TCombobox', fieldbackground='white', background='white', foreground='black', arrowcolor='black')
        
        self.root.option_add('*TCombobox*Listbox.font', ('Segoe UI', 12, 'bold'))
        self.root.option_add('*TCombobox*Listbox.background', 'white')
        self.root.option_add('*TCombobox*Listbox.foreground', 'black')
        self.root.option_add('*TCombobox*Listbox.selectBackground', COLORS['accent'])
        self.root.option_add('*TCombobox*Listbox.selectForeground', 'black')

        self.engine = SquadArchitectEngine()
        self.sliders = {}
        self.team_roster_data = []
        self.active_lineup = {}
        self.quote_indices = [0, 1, 2]
        self.quote_timer = None
        self.show_entrance()

    def show_custom_popup(self, title, message, is_error=False):
        pop = tk.Toplevel(self.root)
        pop.title(title)
        pop.geometry("450x350")
        pop.config(bg=COLORS['bg'])
        pop.attributes('-topmost', True)
        pop.transient(self.root)
        pop.grab_set()

        color = COLORS['accent2'] if is_error else COLORS['accent']
        
        tk.Label(pop, text=title.upper(), font=('Impact', 22), fg=color, bg=COLORS['bg']).pack(pady=(20, 10))
        tk.Label(pop, text=message, font=('Segoe UI', 11), fg='white', bg=COLORS['bg'], justify='center', wraplength=400).pack(pady=10)
        
        btn = tk.Button(pop, text="ACKNOWLEDGE", bg=COLORS['panel'], fg=color, font=('Segoe UI', 10, 'bold'), relief='flat', command=pop.destroy)
        btn.pack(pady=15, ipadx=20, ipady=5)

    def _clear(self):
        if self.quote_timer: self.root.after_cancel(self.quote_timer)
        for w in self.root.winfo_children(): w.destroy()

    def show_entrance(self):
        self._clear()
        bg = tk.Canvas(self.root, bg=COLORS['bg'], highlightthickness=0)
        bg.pack(fill='both', expand=True)
        
        def draw_entrance_bg(event=None):
            bg.delete("grid_shape")
            w = bg.winfo_width()
            h = bg.winfo_height()
            if w < 10: w = 1500
            if h < 10: h = 1000
            
            for i in range(0, w + 100, 50):
                bg.create_line(i, 0, i, h, fill='#111820', tags="grid_shape")
            for i in range(0, h + 100, 50):
                bg.create_line(0, i, w, i, fill='#111820', tags="grid_shape")
                
            bg.create_oval(w/2 - 200, -200, w/2 + 200, 200, outline=COLORS['faded'], width=2, tags="grid_shape")
            bg.tag_lower("grid_shape")

        bg.bind('<Configure>', draw_entrance_bg)

        tf = tk.Frame(bg, bg=COLORS['bg'])
        tf.place(relx=0.5, rely=0.25, anchor='center')
        tk.Label(tf, text="SMART SQUAD AI ", font=('Impact', 75), fg=COLORS['text'], bg=COLORS['bg']).pack()
        tk.Label(tf, text="BECOME A TACTICAL GENIUS", font=('Segoe UI', 16, 'bold'), fg=COLORS['accent'], bg=COLORS['bg']).pack()

        ModernButton(bg, text="ENTER TACTICS BOARD", command=self.show_analysis_hub).place(relx=0.5, rely=0.50, anchor='center')

        self.q_labels = []
        positions = [(0.15, 0.50), (0.85, 0.50), (0.5, 0.85)]
        for x, y in positions:
            f = tk.Frame(bg, bg=COLORS['bg'])
            f.place(relx=x, rely=y, anchor='center')
            q = tk.Label(f, text="", font=('Segoe UI', 13, 'italic'), fg='gray70', bg=COLORS['bg'], justify='center', wraplength=350)
            c = tk.Label(f, text="", font=('Segoe UI', 11, 'bold'), fg=COLORS['accent2'], bg=COLORS['bg'])
            q.pack(pady=5); c.pack()
            self.q_labels.append((q, c))
            
        self.cycle_quotes()

    def cycle_quotes(self):
        for i in range(3):
            q_txt, c_txt = QUOTES[self.quote_indices[i]]
            self.q_labels[i][0].config(text=q_txt)
            self.q_labels[i][1].config(text=c_txt)
            self.quote_indices[i] = (self.quote_indices[i] + 3) % len(QUOTES)
        self.quote_timer = self.root.after(2500, self.cycle_quotes)

    def show_analysis_hub(self):
        self._clear()
        main = tk.Frame(self.root, bg=COLORS['bg'])
        main.pack(fill='both', expand=True)
        side = tk.Frame(main, bg=COLORS['panel'], width=320, highlightbackground=COLORS['border'], highlightthickness=1)
        side.pack(side='left', fill='y')
        
        tk.Label(side, text="ANALYSIS HUB", font=('Impact', 26), fg=COLORS['accent'], bg=COLORS['panel']).pack(pady=20)
        for k in STATS_KEYS:
            tk.Label(side, text=k.upper(), fg=COLORS['text'], bg=COLORS['panel'], font=('Segoe UI', 9, 'bold')).pack(anchor='w', padx=25)
            s = tk.Scale(side, from_=0, to_=99, orient='horizontal', bg=COLORS['panel'], fg=COLORS['accent'], highlightthickness=0, troughcolor='#111')
            s.set(75); s.pack(fill='x', padx=25, pady=2); self.sliders[k] = s

        tk.Button(side, text="LOAD DATASETS", bg=COLORS['accent2'], fg='white', font=('Segoe UI', 10, 'bold'), command=self.trigger_loading).pack(fill='x', padx=30, pady=15)
        tk.Button(side, text="PREDICT & COMPARE", bg=COLORS['accent'], fg='black', font=('Segoe UI', 10, 'bold'), command=self.handle_prediction).pack(fill='x', padx=30, pady=10)
        tk.Button(side, text="TACTICAL BOARD", bg=COLORS['border'], fg='black', font=('Segoe UI', 10, 'bold'), command=self.show_tactical_board).pack(fill='x', padx=30, pady=10)

        self.res_area = tk.Canvas(main, bg=COLORS['bg'], highlightthickness=0)
        self.res_area.pack(side='right', fill='both', expand=True)

        def draw_bg(event=None):
            self.res_area.delete("bg_pitch")
            w = self.res_area.winfo_width()
            h = self.res_area.winfo_height()
            if w < 100: w = 1080
            if h < 100: h = 900
            
            line_color = '#15202b'
            pad_x, pad_y = 60, 60
            
            self.res_area.create_rectangle(pad_x, pad_y, w-pad_x, h-pad_y, outline=line_color, width=3, tags="bg_pitch")
            self.res_area.create_line(w/2, pad_y, w/2, h-pad_y, fill=line_color, width=3, tags="bg_pitch")
            self.res_area.create_oval(w/2-100, h/2-100, w/2+100, h/2+100, outline=line_color, width=3, tags="bg_pitch")
            self.res_area.create_oval(w/2-5, h/2-5, w/2+5, h/2+5, fill=line_color, outline=line_color, tags="bg_pitch")
            self.res_area.create_rectangle(pad_x, h/2-180, pad_x+180, h/2+180, outline=line_color, width=3, tags="bg_pitch")
            self.res_area.create_rectangle(w-pad_x-180, h/2-180, w-pad_x, h/2+180, outline=line_color, width=3, tags="bg_pitch")
            self.res_area.create_rectangle(pad_x, h/2-70, pad_x+60, h/2+70, outline=line_color, width=3, tags="bg_pitch")
            self.res_area.create_rectangle(w-pad_x-60, h/2-70, w-pad_x, h/2+70, outline=line_color, width=3, tags="bg_pitch")
            self.res_area.create_text(w/2, h/2, text="SMART SQUAD AI", font=('Impact', 50), fill='#0d131a', tags="bg_pitch")
            self.res_area.tag_lower("bg_pitch")

        self.res_area.bind('<Configure>', draw_bg)

    def trigger_loading(self):
        paths = filedialog.askopenfilenames(filetypes=[("CSV Files", "*.csv")])
        if not paths: return
        pop = tk.Toplevel(self.root); pop.title("Training"); pop.geometry("400x180"); pop.config(bg=COLORS['panel'])
        tk.Label(pop, text="COOKING...", fg=COLORS['accent'], bg=COLORS['panel'], font=('Segoe UI', 11, 'bold')).pack(pady=15)
        
        prog = ttk.Progressbar(pop, length=300, mode='determinate', style='Horizontal.TProgressbar')
        prog.pack(pady=10)
        
        def task():
            res = self.engine.load_and_train(paths, lambda v: prog.config(value=v) or pop.update_idletasks())
            self.root.after(0, pop.destroy)
            if res is True: 
                msg = f"Models Activated: RF, SVM, KNN, GB, LR\n\nAccuracy:  {self.engine.accuracy:.2f}%\nPrecision: {self.engine.precision:.2f}%\nRecall:    {self.engine.recall:.2f}%\nF1 Score:  {self.engine.f1_score:.2f}%"
                self.show_custom_popup("SYSTEM READY", msg)
            else: 
                self.show_custom_popup("FAILURE", res, is_error=True)
        threading.Thread(target=task, daemon=True).start()

    def generate_reasoning(self, role, stats):
        stat_dict = dict(zip(STATS_KEYS, stats))
        sorted_stats = sorted(stat_dict.items(), key=lambda x: x[1], reverse=True)
        reasons = {
            'Pace': 'explosive speed', 'Shooting': 'lethal finishing',
            'Passing': 'elite vision', 'Dribbling': 'exceptional agility',
            'Defending': 'high defensive awareness', 'Physic': 'dominant physical presence',
            'Goalkeeping': 'goalkeeping reflexes'
        }
        return f"Most efficient as {role} utilizing {reasons.get(sorted_stats[0][0])} and {reasons.get(sorted_stats[1][0])}."

    def handle_prediction(self):
        if not self.engine.is_trained: return self.show_custom_popup("WARNING", "Load datasets first!", True)
        for w in self.res_area.winfo_children(): w.destroy()
        
        stats = [self.sliders[k].get() for k in STATS_KEYS]
        scaled = self.engine.scaler.transform([stats])
        probs = self.engine.model.predict_proba(scaled)[0]
        
        top_indices = np.argsort(probs)[::-1][:3]
        top_roles = self.engine.label_encoder.inverse_transform(top_indices)
        top_probs = probs[top_indices] * 100
        matches = self.engine.find_top_matches(stats)

        header = tk.Frame(self.res_area, bg=COLORS['bg'])
        self.res_area.create_window(50, 40, window=header, anchor='nw', width=900)
        
        tk.Label(header, text=f"PRIMARY ROLE : {top_roles[0]} ({top_probs[0]:.1f}%)", font=('Impact', 42), fg=COLORS['text'], bg=COLORS['bg']).pack(anchor='w')
        tk.Label(header, text=f"TACTICAL ANALYSIS : {self.generate_reasoning(top_roles[0], stats)}", font=('Segoe UI', 12, 'italic'), fg=COLORS['accent'], bg=COLORS['bg']).pack(anchor='w', pady=(0, 5))
        
        versatility_txt = f"VERSATILITY : {top_roles[1]} ({top_probs[1]:.1f}%) , {top_roles[2]} ({top_probs[2]:.1f}%)"
        tk.Label(header, text=versatility_txt, font=('Segoe UI', 14, 'bold'), fg=COLORS['accent2'], bg=COLORS['bg']).pack(anchor='w', pady=(5, 10))

        N = len(STATS_KEYS)
        angles = [n / float(N) * 2 * pi for n in range(N)] + [0]
        plot_stats = stats + [stats[0]]
        best_stats = [self.engine.dataset.iloc[matches[0]['idx']][k] for k in STATS_KEYS]
        plot_best = best_stats + [best_stats[0]]

        fig, ax = plt.subplots(figsize=(6, 6), subplot_kw=dict(polar=True))
        fig.patch.set_facecolor(COLORS['bg'])
        fig.subplots_adjust(bottom=0.1, top=0.85, left=0.1, right=0.75)
        ax.set_facecolor('#0f171e')
        
        ax.plot(angles, plot_stats, color=COLORS['accent'], lw=3)
        ax.fill(angles, plot_stats, color=COLORS['accent'], alpha=0.3)
        ax.plot(angles, plot_best, color=COLORS['accent2'], lw=3)
        ax.fill(angles, plot_best, color=COLORS['accent2'], alpha=0.2)
        
        plt.xticks(angles[:-1], STATS_KEYS, color=COLORS['text'], size=10, fontweight='bold')
        ax.tick_params(colors=COLORS['border'], pad=22)
        ax.set_rlabel_position(0)
        
        canvas_widget = FigureCanvasTkAgg(fig, master=self.res_area).get_tk_widget()
        self.res_area.create_window(50, 200, window=canvas_widget, anchor='nw')

        legend_frame = tk.Frame(self.res_area, bg=COLORS['bg'])
        tk.Label(legend_frame, text="■", fg=COLORS['accent'], bg=COLORS['bg'], font=('Segoe UI', 16)).pack(side='left', padx=(0,5))
        tk.Label(legend_frame, text="Custom Player", fg='white', bg=COLORS['bg'], font=('Segoe UI', 10, 'bold')).pack(side='left', padx=(0,15))
        tk.Label(legend_frame, text="■", fg=COLORS['accent2'], bg=COLORS['bg'], font=('Segoe UI', 16)).pack(side='left', padx=(0,5))
        tk.Label(legend_frame, text=f"Match: {matches[0]['name']}", fg='white', bg=COLORS['bg'], font=('Segoe UI', 10, 'bold')).pack(side='left')
        self.res_area.create_window(800, 160, window=legend_frame, anchor='nw')

        card = tk.Frame(self.res_area, bg=COLORS['panel'], pady=30, padx=40, highlightbackground=COLORS['border'], highlightthickness=2)
        tk.Label(card, text="TOP 3 SCOUTING MATCHES", font=('Impact', 18), fg=COLORS['accent'], bg=COLORS['panel']).pack(pady=(0,25))
        for m in matches: 
            tk.Label(card, text=m['name'].upper(), fg=COLORS['text'], bg=COLORS['panel'], font=('Segoe UI', 12, 'bold')).pack(pady=(15, 0))
            tk.Label(card, text=f"Match Accuracy: {m['sim']:.2f}%", fg=COLORS['accent2'], bg=COLORS['panel'], font=('Segoe UI', 10)).pack(pady=(0, 5))
        
        self.res_area.create_window(800, 200, window=card, anchor='nw')

    def show_tactical_board(self):
        self._clear()
        main = tk.Frame(self.root, bg=COLORS['bg'])
        main.pack(fill='both', expand=True)
        
        side = tk.Frame(main, bg=COLORS['panel'], width=300, highlightbackground=COLORS['border'], highlightthickness=1)
        side.pack(side='left', fill='y')
        
        self.right_panel = tk.Frame(main, bg=COLORS['panel'], width=260, highlightbackground=COLORS['border'], highlightthickness=1)
        self.right_panel.pack(side='right', fill='y')
        
        tk.Label(self.right_panel, text="BENCH", font=('Impact', 22), fg=COLORS['accent'], bg=COLORS['panel']).pack(pady=(20, 5))
        self.bench_container = tk.Frame(self.right_panel, bg=COLORS['panel'])
        self.bench_container.pack(fill='both', expand=True, padx=20, pady=0)
        
        tk.Label(side, text="TACTICAL ANALYSIS", font=('Impact', 26), fg=COLORS['accent'], bg=COLORS['panel']).pack(pady=10)
        self.form = ttk.Combobox(side, values=list(FORMATION_INFO.keys()), state="readonly", font=('Segoe UI', 11, 'bold'))
        self.form.set("4-3-3"); self.form.pack(padx=25, pady=5, fill='x')
        
        self.form.bind("<<ComboboxSelected>>", self.on_formation_change)
        
        tk.Button(side, text="IMPORT NORANI FC", bg=COLORS['accent'], fg='black', font=('Segoe UI', 10, 'bold'), command=self.load_team).pack(fill='x', padx=30, pady=10)
        
        tk.Label(side, text="SQUAD DEPTH", font=('Impact', 16), fg=COLORS['accent2'], bg=COLORS['panel']).pack(pady=(10, 0))
        self.role_search = ttk.Combobox(side, state="readonly", font=('Segoe UI', 11, 'bold'))
        if self.engine.is_trained:
            self.role_search['values'] = list(self.engine.label_encoder.classes_)
            self.role_search.set("ST")
        self.role_search.pack(padx=25, pady=5, fill='x')
        self.role_search.bind("<<ComboboxSelected>>", self.find_best_for_role)
        
        self.best_lbl = tk.Label(side, text="Load team first...", fg='white', bg=COLORS['panel'], font=('Segoe UI', 10, 'bold'), justify='left')
        self.best_lbl.pack(padx=25, pady=0, anchor='w')

        tk.Label(side, text="REPLACE PLAYER", font=('Impact', 16), fg=COLORS['accent'], bg=COLORS['panel']).pack(pady=(10, 0))
        self.sub_out_var = tk.StringVar()
        self.sub_out_combo = ttk.Combobox(side, textvariable=self.sub_out_var, state="readonly", font=('Segoe UI', 11, 'bold'))
        self.sub_out_combo.pack(padx=25, pady=2, fill='x')
        self.sub_in_var = tk.StringVar()
        self.sub_in_combo = ttk.Combobox(side, textvariable=self.sub_in_var, state="readonly", font=('Segoe UI', 11, 'bold'))
        self.sub_in_combo.pack(padx=25, pady=2, fill='x')
        tk.Button(side, text="CONFIRM SUB", bg=COLORS['border'], fg='black', font=('Segoe UI', 9, 'bold'), command=self.perform_substitution).pack(fill='x', padx=30, pady=5)

        tk.Button(side, text="BACK TO ANALYSIS", bg=COLORS['faded'], fg='white', font=('Segoe UI', 9, 'bold'), command=self.show_analysis_hub).pack(fill='x', padx=30, pady=(15, 5))

        self.tactical_card = tk.Frame(side, bg=COLORS['bg'], bd=1, relief='solid', highlightbackground=COLORS['border'])
        self.tactical_card.pack(padx=20, pady=(10, 20), fill='x')
        
        self.lbl_s_title = tk.Label(self.tactical_card, text="STRENGTH", fg=COLORS['accent'], bg=COLORS['bg'], font=('Impact', 12))
        self.lbl_s_title.pack(anchor='w', padx=10, pady=(10,0))
        self.lbl_s_text = tk.Label(self.tactical_card, text="", fg='gray80', bg=COLORS['bg'], font=('Segoe UI', 9), justify='left', wraplength=220)
        self.lbl_s_text.pack(anchor='w', padx=10, pady=(0,5))
        
        self.lbl_w_title = tk.Label(self.tactical_card, text="WEAKNESS", fg=COLORS['accent2'], bg=COLORS['bg'], font=('Impact', 12))
        self.lbl_w_title.pack(anchor='w', padx=10, pady=(5,0))
        self.lbl_w_text = tk.Label(self.tactical_card, text="", fg='gray80', bg=COLORS['bg'], font=('Segoe UI', 9), justify='left', wraplength=220)
        self.lbl_w_text.pack(anchor='w', padx=10, pady=(0,10))

        self.pitch = tk.Canvas(main, bg=COLORS['pitch'], highlightthickness=0)
        self.pitch.pack(fill='both', expand=True, padx=40, pady=40)
        
        self.roles_canvas_frame = tk.Frame(self.pitch, bg=COLORS['panel'], bd=2, relief='solid', highlightbackground=COLORS['border'], padx=15, pady=10)
        self.role_vars = {}
        self.role_combos = {}
        
        tk.Label(self.roles_canvas_frame, text="SET PIECE ROLES", font=('Impact', 20), fg=COLORS['accent'], bg=COLORS['panel']).pack(pady=(0, 10))
        
        roles_list = ["Captain", "Left Corner", "Right Corner", "Short Free Kick", "Long Free Kick", "Penalties"]
        for r in roles_list:
            tk.Label(self.roles_canvas_frame, text=r.upper(), fg=COLORS['text'], bg=COLORS['panel'], font=('Segoe UI', 9, 'bold')).pack(anchor='w', pady=(2,0))
            var = tk.StringVar()
            cb = ttk.Combobox(self.roles_canvas_frame, textvariable=var, state="readonly", width=22, font=('Segoe UI', 11, 'bold'))
            cb.pack(fill='x', pady=(0, 6))
            self.role_vars[r] = var
            self.role_combos[r] = cb

        self.pitch.create_window(740, 80, window=self.roles_canvas_frame, anchor='nw')

        self.update_tactical_desc()
        self.draw_stadium()
        
        if self.team_roster_data:
            self.render_team_on_pitch(recalculate=False)
            self.assign_roles()
            self.update_sub_dropdowns()

    def update_tactical_desc(self):
        raw_text = FORMATION_INFO.get(self.form.get(), "")
        if "WEAKNESS:" in raw_text:
            parts = raw_text.split("WEAKNESS:")
            s_text = parts[0].replace("STRENGTH:", "").strip()
            w_text = parts[1].strip()
            self.lbl_s_text.config(text=s_text)
            self.lbl_w_text.config(text=w_text)

    def on_formation_change(self, event=None):
        self.update_tactical_desc()
        self.draw_stadium()
        if self.team_roster_data:  
            self.render_team_on_pitch(recalculate=True)
            self.assign_roles()

    def find_best_for_role(self, event=None):
        if not self.team_roster_data: return self.best_lbl.config(text="Load NORANI FC.")
        role = self.role_search.get()
        sorted_p = sorted(self.team_roster_data, key=lambda x: x['probs'].get(role, 0), reverse=True)
        if len(sorted_p) >= 2:
            self.best_lbl.config(text=f"1. {sorted_p[0]['name']} ({sorted_p[0]['probs'].get(role, 0)*100:.1f}%)\n2. {sorted_p[1]['name']} ({sorted_p[1]['probs'].get(role, 0)*100:.1f}%)")

    def update_sub_dropdowns(self):
        if not hasattr(self, 'sub_out_combo'): return
        
        on_pitch = [p['name'] for p in self.active_lineup.values()]
        bench = [p['name'] for p in self.team_roster_data if p['name'] not in on_pitch]
        
        self.sub_out_combo['values'] = sorted(on_pitch)
        self.sub_in_combo['values'] = sorted(bench)
        self.sub_out_var.set("Player to remove")
        self.sub_in_var.set("Player to add")

    def perform_substitution(self):
        out_name = self.sub_out_var.get()
        in_name = self.sub_in_var.get()
        
        if out_name not in self.sub_out_combo['values'] or in_name not in self.sub_in_combo['values']: return
            
        target_slot = None
        for slot, p in self.active_lineup.items():
            if p['name'] == out_name:
                target_slot = slot
                break
                
        new_player = next((p for p in self.team_roster_data if p['name'] == in_name), None)
        
        if target_slot and new_player:
            self.active_lineup[target_slot] = new_player
            self.draw_stadium() 
            self.render_team_on_pitch(recalculate=False)
            self.assign_roles()

    def draw_stadium(self):
        self.pitch.delete("all_pitch")
        
        self.pitch.create_text(425, 40, text="NORANI FC", fill='white', font=('Impact', 40), anchor='center', tags="all_pitch")
        self.pitch.create_text(145, 40, text=f"{self.form.get()}", fill=COLORS['accent'], font=('Segoe UI', 16, 'bold'), anchor='w', tags="all_pitch")

        self.pitch.create_rectangle(145, 80, 705, 660, outline='white', width=2, tags="all_pitch")
        self.pitch.create_line(145, 370, 705, 370, fill='white', width=2, tags="all_pitch")
        
        self.pitch.create_oval(345, 290, 505, 450, outline='white', width=2, tags="all_pitch")
        self.pitch.create_oval(421, 366, 429, 374, fill='white', outline='white', tags="all_pitch")
        
        self.pitch.create_rectangle(265, 80, 585, 200, outline='white', width=2, tags="all_pitch")
        self.pitch.create_rectangle(345, 80, 505, 130, outline='white', width=2, tags="all_pitch")
        self.pitch.create_arc(355, 140, 495, 260, start=180, extent=180, outline='white', width=2, style=tk.ARC, tags="all_pitch")

        self.pitch.create_rectangle(265, 540, 585, 660, outline='white', width=2, tags="all_pitch")
        self.pitch.create_rectangle(345, 610, 505, 660, outline='white', width=2, tags="all_pitch")
        self.pitch.create_arc(355, 480, 495, 600, start=0, extent=180, outline='white', width=2, style=tk.ARC, tags="all_pitch")

    def load_team(self):
        if not self.engine.is_trained: return self.show_custom_popup("WARNING", "Load global data first!", True)
        path = filedialog.askopenfilename(filetypes=[("CSV Files", "*.csv")])
        if not path: return
        self.draw_stadium()
        df = pd.read_csv(path)
        
        name_col = next((c for c in df.columns if any(x in c.lower() for x in ['name', 'player', 'short'])), None)
        
        self.team_roster_data = []
        classes = self.engine.label_encoder.classes_
        
        for idx, row in df.iterrows():
            vals = [row.get(k, row.get(k.lower(), 0)) for k in STATS_KEYS]
            prob_array = self.engine.model.predict_proba(self.engine.scaler.transform([vals]))[0]
            
            p_name = str(row[name_col]) if name_col else f"Player {idx}"
            
            self.team_roster_data.append({
                'name': p_name.upper(),
                'probs': dict(zip(classes, prob_array)),
                'best_role': classes[np.argmax(prob_array)],
                'total_stats': sum(vals),
                'stats': dict(zip(STATS_KEYS, vals))
            })
            
        self.find_best_for_role() 
        self.render_team_on_pitch(recalculate=True)
        self.assign_roles()

    def assign_roles(self):
        if not self.active_lineup: return
        
        active_players = list(self.active_lineup.values())
        roles_list = ["Captain", "Left Corner", "Right Corner", "Short Free Kick", "Long Free Kick", "Penalties"]
        
        for role in roles_list:
            if role == "Captain":
                saim_player = next((p for p in active_players if "SAIM" in p['name'].upper()), active_players[0])
                options = [p['name'] for p in active_players]
                self.role_combos[role]['values'] = options
                self.role_vars[role].set(saim_player['name'])
                continue
                
            scored_players = []
            for p in active_players:
                score = 0
                stats = p['stats']
                if role == "Penalties": 
                    score = (stats['Shooting']*0.7 + stats['Physic']*0.3)
                elif role == "Short Free Kick": 
                    score = (stats['Passing']*0.6 + stats['Shooting']*0.4)
                elif role == "Long Free Kick": 
                    score = (stats['Passing']*0.7 + stats['Shooting']*0.3)
                elif role in ["Left Corner", "Right Corner"]: 
                    score = (stats['Passing']*0.6 + stats['Dribbling']*0.4)
                
                perc = min(99.9, (score / 99.0) * 100)
                scored_players.append((p['name'], perc))
                
            scored_players.sort(key=lambda x: x[1], reverse=True)
            options = [f"{name} ({perc:.1f}%)" for name, perc in scored_players]
            
            self.role_combos[role]['values'] = options
            self.role_vars[role].set(options[0])

    def render_team_on_pitch(self, recalculate=True):
        f_map = {
            "4-3-3": {"GK":(425, 620), "LB":(205, 510), "CB":(335, 530), "CB2":(515, 530), "RB":(645, 510), "CM":(425, 390), "CM2":(305, 390), "CM3":(545, 390), "LW":(235, 210), "RW":(615, 210), "ST":(425, 140)},
            "4-4-2": {"GK":(425, 620), "LB":(205, 510), "CB":(335, 530), "CB2":(515, 530), "RB":(645, 510), "LM":(215, 380), "CM":(335, 380), "CM2":(515, 380), "RM":(635, 380), "ST":(345, 160), "ST2":(505, 160)},
            "3-5-2": {"GK":(425, 620), "CB":(265, 530), "CB2":(425, 530), "CB3":(585, 530), "LB":(185, 380), "RB":(665, 380), "CM":(335, 420), "CM2":(515, 420), "CAM":(425, 320), "ST":(345, 160), "ST2":(505, 160)},
            "5-4-1": {"GK":(425, 620), "LB":(185, 510), "CB":(285, 530), "CB2":(425, 530), "CB3":(565, 530), "RB":(665, 510), "LM":(235, 370), "CM":(355, 370), "CM2":(495, 370), "RM":(615, 370), "ST":(425, 150)},
            "4-2-3-1": {"GK":(425, 620), "LB":(205, 510), "CB":(335, 530), "CB2":(515, 530), "RB":(645, 510), "CDM":(335, 440), "CDM2":(515, 440), "CAM":(425, 300), "LM":(225, 290), "RM":(625, 290), "ST":(425, 140)}
        }
        
        coords = f_map.get(self.form.get(), f_map["4-3-3"])
        
        if recalculate:
            self.active_lineup = {}
            used = set()
            for slot, (x, y) in coords.items():
                b_role = ''.join([i for i in slot if not i.isdigit()])
                df_sorted = sorted(self.team_roster_data, key=lambda p: p['probs'].get(b_role, 0), reverse=True)
                
                match = next((p for p in df_sorted if p['name'] not in used and p['best_role'] == b_role), None)
                if not match: match = next((p for p in df_sorted if p['name'] not in used and b_role in p['best_role']), None)
                if not match: match = next((p for p in df_sorted if p['name'] not in used), None)
                    
                if match:
                    used.add(match['name'])
                    self.active_lineup[slot] = match
        
        for slot, (x, y) in coords.items():
            if slot in self.active_lineup:
                match = self.active_lineup[slot]
                self.pitch.create_oval(x-12, y-12, x+12, y+12, fill=COLORS['accent'], outline='black', width=2, tags="all_pitch")
                
                txt_id = self.pitch.create_text(x, y+36, text=f"{match['name']}\n({match['best_role']})", fill='black', font=('Segoe UI', 9, 'bold'), justify='center', tags="all_pitch")
                
                bbox = self.pitch.bbox(txt_id)
                pad = 1
                bg_rect = self.pitch.create_rectangle(bbox[0]-pad, bbox[1]-pad, bbox[2]+pad, bbox[3]+pad, fill=COLORS['pitch'], outline=COLORS['pitch'], tags="all_pitch")
                self.pitch.tag_lower(bg_rect, txt_id)
                
        for widget in self.bench_container.winfo_children():
            widget.destroy()
            
        on_pitch_names = [p['name'] for p in self.active_lineup.values()]
        bench_players = [p for p in self.team_roster_data if p['name'] not in on_pitch_names]
        
        for p in bench_players:
            tk.Label(self.bench_container, text=f"{p['name']} ({p['best_role']})", fg=COLORS['text'], bg=COLORS['panel'], font=('Segoe UI', 11, 'bold')).pack(anchor='w', pady=4)
                
        self.update_sub_dropdowns()

if __name__ == "__main__":
    root = tk.Tk()
    app = TacticalApp(root)
    root.mainloop()