import pandas as pd
import numpy as np
import traceback
from sklearn.preprocessing import LabelEncoder, StandardScaler
from sklearn.ensemble import RandomForestClassifier, VotingClassifier, GradientBoostingClassifier
from sklearn.svm import SVC
from sklearn.neighbors import KNeighborsClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, precision_recall_fscore_support
from Config import STATS_KEYS
from sklearn.model_selection import StratifiedKFold, cross_validate

def evaluate_ensemble_rigorously(self):
    X = self.scaler.fit_transform(self.dataset[STATS_KEYS])
    y = self.label_encoder.fit_transform(self.dataset['target'])
    
    cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)
    scoring = ['accuracy', 'precision_weighted', 'recall_weighted', 'f1_weighted']
    
    scores = cross_validate(self.model, X, y, cv=cv, scoring=scoring, n_jobs=-1)
    
    self.mean_accuracy = np.mean(scores['test_accuracy']) * 100
    self.mean_precision = np.mean(scores['test_precision_weighted']) * 100
    self.mean_recall = np.mean(scores['test_recall_weighted']) * 100
    self.mean_f1 = np.mean(scores['test_f1_weighted']) * 100

    def get_feature_importances(self):
   
        return None
    rf_model = self.model.named_estimators_['rf']
    importances = rf_model.feature_importances_
    return dict(zip(STATS_KEYS, importances))

class SquadArchitectEngine:
    def __init__(self):
        self.model = None
        self.scaler = StandardScaler()
        self.label_encoder = LabelEncoder()
        self.dataset = None
        self.is_trained = False
        self.name_col = None
        self.accuracy = 0.0
        self.precision = 0.0
        self.recall = 0.0
        self.f1_score = 0.0

    def load_and_train(self, filepaths, progress_callback):
        try:
            data_frames = []
            for i, path in enumerate(filepaths):
                df = pd.read_csv(path, low_memory=False)
                
                target_col = next((c for c in df.columns if 'pos' in str(c).lower()), None)
                if not target_col:
                    continue

                extracted = pd.DataFrame()
                
                target_series = df[target_col].astype(str).str.split(',').str[0].str.strip()
                extracted.insert(0, 'target', target_series)
                
                name_col = next((c for c in df.columns if str(c).lower() in ['short_name', 'name', 'player_name', 'long_name']), None)
                if name_col:
                    extracted.insert(1, 'Player_Name_Std', df[name_col])
                else:
                    extracted.insert(1, 'Player_Name_Std', "Unknown Player")

                for stat in STATS_KEYS:
                    stat_col = None
                    if stat == 'Goalkeeping':
                        stat_col = next((c for c in df.columns if 'gk' in str(c).lower() or 'goalkeeping' in str(c).lower()), None)
                    else:
                        stat_col = next((c for c in df.columns if stat.lower() in str(c).lower() and 'total' not in str(c).lower()), None)
                    
                    if stat_col:
                        extracted[stat] = pd.to_numeric(df[stat_col], errors='coerce').fillna(10 if stat == 'Goalkeeping' else 50)
                    else:
                        extracted[stat] = 10 if stat == 'Goalkeeping' else 50
                        
                data_frames.append(extracted)
                progress_callback((i + 1) / len(filepaths) * 40)

            if not data_frames:
                return "Error: No files contained a valid position column (expected 'pos' in header)."

            combined_df = pd.concat(data_frames, ignore_index=True)
            
            if 'target' not in combined_df.columns:
                return "Critical Data Error: Target column failed to construct."
                
            combined_df = combined_df.dropna(subset=['target'])
            combined_df = combined_df[~combined_df['target'].str.lower().isin(['nan', 'none', ''])]
            
            if combined_df.empty:
                return "Error: Dataset is empty after filtering."

            if len(combined_df) > 27000:
                combined_df = combined_df.sample(n=27000, random_state=42)

            self.dataset = combined_df.reset_index(drop=True)
            self.name_col = 'Player_Name_Std'
            progress_callback(60)

            X = self.scaler.fit_transform(self.dataset[STATS_KEYS])
            y = self.label_encoder.fit_transform(self.dataset['target'])
            X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
            
            self.model = VotingClassifier(estimators=[
                ('rf', RandomForestClassifier(n_estimators=30, max_depth=8, random_state=42)),
                ('svm', SVC(probability=True, kernel='linear', cache_size=1000, random_state=42)),
                ('knn', KNeighborsClassifier(n_neighbors=5)),
                ('gb', GradientBoostingClassifier(n_estimators=30, learning_rate=0.1, random_state=42)),
                ('lr', LogisticRegression(max_iter=200, random_state=42))
            ], voting='soft')
            
            self.model.fit(X_train, y_train)
            
            y_pred = self.model.predict(X_test)
            self.accuracy = accuracy_score(y_test, y_pred) * 100
            
            prec, rec, f1, _ = precision_recall_fscore_support(y_test, y_pred, average='weighted', zero_division=0)
            self.precision = prec * 100
            self.recall = rec * 100
            self.f1_score = f1 * 100
            
            self.is_trained = True
            progress_callback(100)
            return True
            
        except Exception as e:
            return str(traceback.format_exc())

    def find_top_matches(self, input_stats):
        distances = np.linalg.norm(self.dataset[STATS_KEYS].values - input_stats, axis=1)
        top_idx = distances.argsort()[:3]
        matches = []
        for idx in top_idx:
            raw_name = str(self.dataset.iloc[idx][self.name_col])
            clean_name = raw_name.replace('-', ' ').title()
            matches.append({'name': clean_name, 'sim': max(0, 100 - (distances[idx] / 261.9) * 100), 'idx': idx})
        return matches