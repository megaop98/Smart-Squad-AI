import numpy as np
import matplotlib.pyplot as plt

def draw_svm_diagram():
    fig, ax = plt.subplots(figsize=(10, 8))
    fig.patch.set_facecolor('#1f2833')
    ax.set_facecolor('#0b0c10')
    
    np.random.seed(42)
    defenders_x = np.random.normal(30, 10, 20)
    defenders_y = np.random.normal(80, 10, 20)
    
    attackers_x = np.random.normal(80, 10, 20)
    attackers_y = np.random.normal(30, 10, 20)

    ax.scatter(defenders_x, defenders_y, color='#66fcf1', s=100, label='Defenders (Class A)', edgecolors='white', zorder=3)
    ax.scatter(attackers_x, attackers_y, color='#ff007f', s=100, label='Attackers (Class B)', edgecolors='white', zorder=3)

    x_line = np.linspace(0, 100, 100)
    y_line = x_line
    ax.plot(x_line, y_line, color='white', lw=3, label='Optimal Hyperplane', zorder=2)

    y_margin_top = x_line + 15
    y_margin_bottom = x_line - 15
    ax.plot(x_line, y_margin_top, color='#45a29e', lw=2, linestyle='--', label='Margin', zorder=2)
    ax.plot(x_line, y_margin_bottom, color='#45a29e', lw=2, linestyle='--', zorder=2)

    ax.scatter([45, 55], [60, 40], facecolors='none', edgecolors='yellow', s=300, lw=3, label='Support Vectors', zorder=4)

    ax.set_xlim(0, 100)
    ax.set_ylim(0, 100)
    ax.set_xlabel("Shooting Attribute", color='white', fontsize=12, fontweight='bold')
    ax.set_ylabel("Defending Attribute", color='white', fontsize=12, fontweight='bold')
    ax.tick_params(colors='white')
    ax.legend(facecolor='#1f2833', labelcolor='white', edgecolor='#45a29e')
    
    plt.title("Support Vector Machine (SVM) - Hyperplane Separation", fontsize=16, fontweight='bold', color='white', pad=20)
    plt.tight_layout()
    plt.show()

if __name__ == "__main__":
    draw_svm_diagram()