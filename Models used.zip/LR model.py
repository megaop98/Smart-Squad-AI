import numpy as np
import matplotlib.pyplot as plt

def draw_logistic_regression_diagram():
    fig, ax = plt.subplots(figsize=(10, 6))
    fig.patch.set_facecolor('#1f2833')
    ax.set_facecolor('#0b0c10')
    
    x = np.linspace(-10, 10, 200)
    y = 1 / (1 + np.exp(-x))
    
    ax.plot(x, y, color='#66fcf1', lw=4, label='Sigmoid Curve')
    
    ax.axhline(0.5, color='#ff007f', linestyle='--', lw=2, label='Decision Threshold (0.5)')
    
    np.random.seed(42)
    x_class0 = np.random.uniform(-10, -2, 15)
    y_class0 = np.zeros_like(x_class0)
    
    x_class1 = np.random.uniform(2, 10, 15)
    y_class1 = np.ones_like(x_class1)
    
    ax.scatter(x_class0, y_class0, color='#45a29e', s=100, edgecolors='white', label='Not Striker (Class 0)', zorder=5)
    ax.scatter(x_class1, y_class1, color='#ff007f', s=100, edgecolors='white', label='Striker (Class 1)', zorder=5)

    ax.vlines(0, 0, 1, color='white', linestyle='-', lw=1, alpha=0.3)
    
    ax.set_xlim(-10, 10)
    ax.set_ylim(-0.1, 1.1)
    ax.set_xlabel("Linear Combination of Features (Pace, Shooting, etc.)", color='white', fontsize=12, fontweight='bold')
    ax.set_ylabel("Probability of Role", color='white', fontsize=12, fontweight='bold')
    ax.tick_params(colors='white')
    ax.legend(loc='center right', facecolor='#1f2833', labelcolor='white', edgecolor='#45a29e')
    
    plt.title("Logistic Regression - Sigmoid Probability Function", fontsize=16, fontweight='bold', color='white', pad=20)
    plt.tight_layout()
    plt.show()

if __name__ == "__main__":
    draw_logistic_regression_diagram()