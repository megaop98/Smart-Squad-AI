import matplotlib.pyplot as plt
import matplotlib.patches as patches

def draw_gradient_boosting_diagram():
    fig, ax = plt.subplots(figsize=(12, 8))
    fig.patch.set_facecolor('#1f2833')
    ax.set_facecolor('#1f2833')
    ax.set_xlim(0, 100)
    ax.set_ylim(0, 100)
    ax.axis('off')
    
    def draw_box(x, y, w, h, text, color, text_col='white'):
        rect = patches.Rectangle((x, y), w, h, linewidth=2, edgecolor='#45a29e', facecolor=color)
        ax.add_patch(rect)
        ax.text(x + w/2, y + h/2, text, ha='center', va='center', color=text_col, fontsize=10, fontweight='bold')
        return (x + w/2, y)
    
    def draw_arrow(x1, y1, x2, y2, text=""):
        ax.annotate("", xy=(x2, y2), xytext=(x1, y1),
                    arrowprops=dict(arrowstyle="->", lw=2, color='#ff007f'))
        if text:
            ax.text((x1+x2)/2, (y1+y2)/2 + 2, text, color='white', ha='center', fontsize=9, fontweight='bold')

    draw_box(10, 75, 20, 12, "Base Model\n(Predicts Mean)", color='#2c3e50')
    
    draw_arrow(30, 81, 40, 81, "Calculate Errors")
    
    draw_box(40, 75, 20, 12, "Tree 1\n(Fits Residuals)", color='#133520')
    
    draw_arrow(60, 81, 70, 81, "Update Prediction")
    
    draw_box(70, 75, 20, 12, "Model 1\n(Base + LR * Tree 1)", color='#2c3e50')

    draw_arrow(80, 75, 80, 60)
    draw_arrow(80, 60, 30, 60)
    draw_arrow(30, 60, 30, 47)
    ax.text(55, 62, "Calculate New Residuals (Errors)", color='white', ha='center', fontsize=9, fontweight='bold')

    draw_box(10, 35, 20, 12, "Model 1", color='#2c3e50')
    
    draw_arrow(30, 41, 40, 41)
    
    draw_box(40, 35, 20, 12, "Tree 2\n(Fits New Residuals)", color='#133520')
    
    draw_arrow(60, 41, 70, 41)
    
    draw_box(70, 35, 20, 12, "Model 2\n(Model 1 + LR * Tree 2)", color='#2c3e50')

    draw_arrow(80, 35, 80, 20)
    
    ax.text(80, 15, ". . . Iterates N times . . .", color='white', ha='center', fontsize=12, fontweight='bold')
    
    draw_box(35, 5, 30, 10, "FINAL STRONG CLASSIFIER\nSum(Base + Trees)", color='#66fcf1', text_col='black')

    plt.title("Gradient Boosting Classifier - Sequential Learning", fontsize=16, fontweight='bold', color='white', pad=20)
    plt.tight_layout()
    plt.show()

if __name__ == "__main__":
    draw_gradient_boosting_diagram()