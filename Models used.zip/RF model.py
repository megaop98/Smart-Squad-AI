import matplotlib.pyplot as plt
import matplotlib.patches as patches

def draw_random_forest_diagram():
    fig, ax = plt.subplots(figsize=(12, 8))
    fig.patch.set_facecolor('#1f2833')
    ax.set_facecolor('#1f2833')
    ax.set_xlim(0, 100)
    ax.set_ylim(0, 100)
    ax.axis('off')
    
    def draw_box(x, y, w, h, text, color, text_col='white'):
        rect = patches.Rectangle((x, y), w, h, linewidth=2, edgecolor='#45a29e', facecolor=color)
        ax.add_patch(rect)
        ax.text(x + w/2, y + h/2, text, ha='center', va='center', color=text_col, fontsize=10, fontweight='bold')
        return (x + w/2, y)
    
    def draw_arrow(x1, y1, x2, y2):
        ax.annotate("", xy=(x2, y2), xytext=(x1, y1),
                    arrowprops=dict(arrowstyle="->", lw=2, color='#66fcf1'))

    draw_box(40, 90, 20, 8, "INPUT DATA\n(Pace, Shooting, etc.)", color='#2c3e50')
    
    draw_arrow(50, 90, 20, 75)
    draw_arrow(50, 90, 50, 75)
    draw_arrow(50, 90, 80, 75)

    draw_box(10, 60, 20, 15, "Decision Tree 1\n\nDefending > 80?\nPace < 50?", color='#133520')
    ax.text(20, 55, "Prediction:\nCENTER BACK", ha='center', fontsize=9, color='#66fcf1', fontweight='bold')
    
    draw_box(40, 60, 20, 15, "Decision Tree 2\n\nPassing > 85?\nDribbling > 80?", color='#133520')
    ax.text(50, 55, "Prediction:\nMIDFIELDER", ha='center', fontsize=9, color='#66fcf1', fontweight='bold')
    
    draw_box(70, 60, 20, 15, "Decision Tree 3\n\nShooting > 85?\nPace > 80?", color='#133520')
    ax.text(80, 55, "Prediction:\nSTRIKER", ha='center', fontsize=9, color='#66fcf1', fontweight='bold')

    ax.text(50, 50, ". . . (100 Trees in Forest) . . .", ha='center', fontsize=12, fontweight='bold', color='white')

    draw_arrow(20, 52, 50, 35)
    draw_arrow(50, 52, 50, 35)
    draw_arrow(80, 52, 50, 35)

    draw_box(35, 25, 30, 10, "MAJORITY VOTING\n(Aggregation)", color='#2c3e50')
    
    draw_arrow(50, 25, 50, 15)

    draw_box(40, 5, 20, 10, "FINAL OUTPUT\n(Predicted Position)", color='#ff007f')

    plt.title("Random Forest Classifier Architecture", fontsize=16, fontweight='bold', color='white', pad=20)
    plt.tight_layout()
    plt.show()

if __name__ == "__main__":
    draw_random_forest_diagram()