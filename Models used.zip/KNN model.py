import numpy as np
import matplotlib.pyplot as plt
import matplotlib.patches as patches

def draw_knn_diagram():
    fig, ax = plt.subplots(figsize=(10, 8))
    fig.patch.set_facecolor('#1f2833')
    ax.set_facecolor('#0b0c10')
    
    np.random.seed(10)
    cm_x = np.random.normal(50, 12, 30)
    cm_y = np.random.normal(50, 12, 30)
    
    st_x = np.random.normal(85, 8, 20)
    st_y = np.random.normal(20, 8, 20)
    
    cb_x = np.random.normal(20, 8, 20)
    cb_y = np.random.normal(85, 8, 20)

    target_x, target_y = 60, 45

    ax.scatter(cm_x, cm_y, color='#66fcf1', s=80, label='Midfielders', alpha=0.6)
    ax.scatter(st_x, st_y, color='#ff007f', s=80, label='Strikers', alpha=0.6)
    ax.scatter(cb_x, cb_y, color='#45a29e', s=80, label='Defenders', alpha=0.6)

    ax.scatter(target_x, target_y, color='yellow', s=200, marker='*', label='Unknown Player', edgecolors='black')

    circle = patches.Circle((target_x, target_y), radius=18, fill=False, color='white', linestyle='--', linewidth=2)
    ax.add_patch(circle)

    neighbors_x = [52, 58, 65, 55, 68]
    neighbors_y = [48, 55, 42, 38, 50]
    
    for nx, ny in zip(neighbors_x, neighbors_y):
        ax.plot([target_x, nx], [target_y, ny], color='white', lw=1.5, zorder=1)
        ax.scatter(nx, ny, color='#66fcf1', s=120, edgecolors='white', zorder=2)

    ax.text(62, 22, "K=5 Nearest Neighbors\nMajority Vote = Midfielder", color='white', fontsize=12, fontweight='bold')

    ax.set_xlim(0, 100)
    ax.set_ylim(0, 100)
    ax.set_xlabel("Passing Accuracy", color='white', fontsize=12, fontweight='bold')
    ax.set_ylabel("Dribbling Skill", color='white', fontsize=12, fontweight='bold')
    ax.tick_params(colors='white')
    ax.legend(facecolor='#1f2833', labelcolor='white', edgecolor='#45a29e')
    
    plt.title("K-Nearest Neighbors (KNN) Clustering", fontsize=8, fontweight='bold', color='white', pad=20)
    plt.tight_layout()
    plt.show()

if __name__ == "__main__":
    draw_knn_diagram()